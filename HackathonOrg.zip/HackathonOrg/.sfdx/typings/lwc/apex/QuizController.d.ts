declare module "@salesforce/apex/QuizController.getQuizData" {
  export default function getQuizData(): Promise<any>;
}
