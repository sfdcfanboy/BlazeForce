import { LightningElement, track, wire } from 'lwc';
import getQuizData from '@salesforce/apex/QuizController.getQuizData';

export default class QuizComponent extends LightningElement {
    @track quizData;
    @track result;

    @wire(getQuizData)
    wiredQuizData({ error, data }) {
        if (data) {
            this.quizData = data.map(quiz => ({
                ...quiz,
                options: [
                    { label: quiz.Option_A__c, value: 'A' },
                    { label: quiz.Option_B__c, value: 'B' },
                    { label: quiz.Option_C__c, value: 'C' }
                ],
                selectedOption: null
            }));
        } else if (error) {
            console.error(error);
        }
    }

    handleOptionChange(event) {
        const quizId = event.target.dataset.id;
        const selectedOption = event.detail.value;
        this.quizData = this.quizData.map(quiz => {
            if (quiz.Id === quizId) {
                return { ...quiz, selectedOption };
            }
            return quiz;
        });
    }

    handleSubmit() {
        this.result = this.quizData.map(quiz => {
            const isCorrect = quiz.selectedOption === quiz.Correct_Option__c;
            return `${quiz.selectedOption}: ${isCorrect ? 'Correct' : 'Incorrect'}`;
        }).join('\n');
    }
}