import { LightningElement } from 'lwc';

export default class Orgsas extends LightningElement {}